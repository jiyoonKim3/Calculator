package com.bulogu.test.user;

public class UserTest {
	
}
