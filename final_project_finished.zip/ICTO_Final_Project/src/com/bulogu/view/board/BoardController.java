package com.bulogu.view.board;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.bulogu.biz.board.impl.BoardDAO;
import com.bulogu.biz.board.vo.BoardVO;
import com.bulogu.biz.user.vo.UserVO;


@Controller
public class BoardController {
	
	@Autowired
	@Qualifier("boardDAO")
	private BoardDAO boardDao;
	
	@RequestMapping(method=RequestMethod.POST, value="/addBoard.do")
	public String addBoard(BoardVO vo, HttpSession session, Model model, HttpServletRequest request){
		
		UserVO user = (UserVO)session.getAttribute("user");
		if(user == null){
			return "login.jsp";
		}
		
		UserVO host = (UserVO)session.getAttribute("host");
		vo.setB_writer(user.getUserid());
		vo.setB_receiver(host.getUserid());
		
		
		MultipartFile uploadFile = vo.getUploadFile();
		String fileName = "";
		
//		String savePath = request.getServletContext().getRealPath("");
		
		if(uploadFile != null && uploadFile.getOriginalFilename().length() > 0){
			fileName = uploadFile.getOriginalFilename();
			FileOutputStream output = null;
			
			String path = request.getServletContext().getRealPath("/images");
			
			try {
				byte[] fileData = uploadFile.getBytes();
				output = new FileOutputStream(path+"/" + fileName);
//				output = new FileOutputStream("localhost/ICTO_Final_Project/WebContent/images/" + fileName);
//				output = new FileOutputStream(savePath+"/images" + fileName);
				output.write(fileData);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}finally{
				try {
					output.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
		vo.setB_picture(fileName);
		
		boardDao.addBoard(vo);
		HashMap<String, Object> map = new HashMap<>();
		
		map.put("b_receiver", host.getUserid());
		map.put("pageNo", 1);		
		
		BoardVO board = boardDao.getBoardWithPageNo(map);
		
		model.addAttribute("board", board);
		model.addAttribute("boardCount", boardDao.getCountBoard(host.getUserid()));
		return "index.jsp";
	}
	
	@RequestMapping("/goToUpdateBoard.do")
	public String goToUpdateBoard(String b_no, Model md){
		
		BoardVO oneBoard = boardDao.getBoard(Integer.parseInt(b_no));
		md.addAttribute("oneBoard", oneBoard);
		
		return "updateBoard.jsp";
	}
	
	@RequestMapping("/updateBoard.do")
	public String updateBoard(BoardVO vo, HttpSession session, Model model, HttpServletRequest request){
		
		UserVO user = (UserVO)session.getAttribute("user");
		if(user == null){
			return "login.jsp";
		}
		
		UserVO host = (UserVO)session.getAttribute("host");
		vo.setB_writer(user.getUserid());
		vo.setB_receiver(host.getUserid());
		
		MultipartFile uploadFile = vo.getUploadFile();
		String fileName = "";
		
//		String savePath = request.getServletContext().getRealPath("");
		
		if(uploadFile != null && uploadFile.getOriginalFilename().length() > 0){
			fileName = uploadFile.getOriginalFilename();
			FileOutputStream output = null;
			
			String path = request.getServletContext().getRealPath("/images");
			
			try {
				byte[] fileData = uploadFile.getBytes();
				output = new FileOutputStream(path+"/" + fileName);
//				output = new FileOutputStream("localhost/ICTO_Final_Project/WebContent/images/" + fileName);
//				output = new FileOutputStream(savePath+"/images" + fileName);
				output.write(fileData);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}finally{
				try {
					output.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
		vo.setB_picture(fileName);		
		
		boardDao.updateBoard(vo);
		
		
		
		HashMap<String, Object> map = new HashMap<>();
		
		map.put("b_receiver", host.getUserid());
		map.put("pageNo", 1);		
		/*search.setB_receiver(user.getUserid());
		search.setPageNo(1);*/
		
		BoardVO board = boardDao.getBoardWithPageNo(map);
		
		model.addAttribute("board", board);
		model.addAttribute("boardCount", boardDao.getCountBoard(user.getUserid()));

		return "index.jsp";
	}
	
	@RequestMapping("/getBoardWithPageNo.do")
	@ResponseBody
	public BoardVO getBoardWithPageNum(HttpSession session, int pageNo){
		
		UserVO host = (UserVO)session.getAttribute("host");
		
		HashMap<String, Object> map = new HashMap<>();
		map.put("b_receiver", host.getUserid());
		map.put("pageNo", pageNo);		
		boardDao.getBoardWithPageNo(map);
		
		return boardDao.getBoardWithPageNo(map);
	}
	
	@RequestMapping("/deleteBoard.do")
	public String deleteBoard(int b_no, HttpSession session, Model md){
		
		boardDao.deleteBoard(b_no);
		UserVO user = (UserVO)session.getAttribute("host");
		
		HashMap<String, Object> map = new HashMap<>();
		map.put("b_receiver", user.getUserid());
		map.put("pageNo", 1);
		
		int countBoard = boardDao.getCountBoard(user.getUserid());
		
		if(countBoard > 0){
//			BoardVO board = boardDao.getBoardWithPageNo(map);
			md.addAttribute("board", boardDao.getBoardWithPageNo(map));
			md.addAttribute("boardCount", boardDao.getCountBoard(user.getUserid()));
			
		}

		return "index.jsp";
	}
	
	@RequestMapping("/index.do")
	public String index(HttpSession session, int pageNo, Model model){
		
		UserVO host = (UserVO)session.getAttribute("host");
		UserVO user = (UserVO)session.getAttribute("user");
		
		if(user == null){
			return "login.jsp";
		}
		
		
		
		HashMap<String, Object> map = new HashMap<>();
		map.put("b_receiver", host.getUserid());
		if(pageNo == 0){
			map.put("pageNo", 1);
		}else{
			map.put("pageNo", pageNo);
		}

		int countBoard = boardDao.getCountBoard(host.getUserid());
		
		if(countBoard > 0){
//			BoardVO board = boardDao.getBoardWithPageNo(map);
			model.addAttribute("board", boardDao.getBoardWithPageNo(map));
			model.addAttribute("boardCount", boardDao.getCountBoard(host.getUserid()));

		}
		
		return "index.jsp";
	}
	
	@RequestMapping("/myIndex.do")
	public String myIndex(HttpSession session, int pageNo, Model model){
		
		UserVO user = (UserVO)session.getAttribute("user");
		session.setAttribute("host", user);

		if(user == null){
			return "login.jsp";
		}
		
		HashMap<String, Object> map = new HashMap<>();
		map.put("b_receiver", user.getUserid());
		map.put("pageNo", 1);
		
		int countBoard = boardDao.getCountBoard(user.getUserid());
		
		if(countBoard > 0){
//			BoardVO board = boardDao.getBoardWithPageNo(map);
			model.addAttribute("board", boardDao.getBoardWithPageNo(map));
			model.addAttribute("boardCount", boardDao.getCountBoard(user.getUserid()));
			
		}
		
		return "index.jsp";
	}
	
}
