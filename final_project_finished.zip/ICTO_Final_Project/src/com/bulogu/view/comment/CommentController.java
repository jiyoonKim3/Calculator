package com.bulogu.view.comment;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bulogu.biz.comment.impl.CommentDAO;
import com.bulogu.biz.comment.vo.CommentVO;
import com.bulogu.biz.user.vo.UserVO;

@Controller
public class CommentController {

	@Autowired
	@Qualifier("commentDAO")
	private CommentDAO commentDao;
	
	@RequestMapping("/addComment.do")
	@ResponseBody
	public ArrayList<CommentVO> addComment(int b_no, String c_content, HttpSession session){
		UserVO user = (UserVO)session.getAttribute("user");
		
		CommentVO vo = new CommentVO(0, b_no, user.getUserid(), c_content, null);
		System.out.println(vo);
		commentDao.addComment(vo);
		
		return commentDao.getCommentList(b_no);
	}
	
	@RequestMapping("/deleteComment.do")
	@ResponseBody
	public ArrayList<CommentVO> deleteComment(int c_no, int b_no, HttpSession session){
		
		commentDao.deleteComment(c_no);
		
		return commentDao.getCommentList(b_no);
	}
	
	@RequestMapping("/updateComment.do")
	@ResponseBody
	public ArrayList<CommentVO> updateComment(int c_no, int b_no, String c_content, HttpSession session){
		System.out.println("updateComment");
		CommentVO vo = new CommentVO(c_no, b_no, null, c_content, null);
		commentDao.updateComment(vo);
		
		return commentDao.getCommentList(b_no);
	}
}
