package com.bulogu.view.user;

import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bulogu.biz.board.impl.BoardDAO;
import com.bulogu.biz.board.vo.BoardVO;
import com.bulogu.biz.user.impl.UserDAO;
import com.bulogu.biz.user.vo.FriendVO;
import com.bulogu.biz.user.vo.UserVO;

@Controller
public class UserController {
	@Autowired
	private UserDAO dao;
	
	@Autowired
	@Qualifier("boardDAO")
	private BoardDAO boardDao;
	
	@RequestMapping("/memberJoin.do")
	public String memberJoin(UserVO vo){
		
		dao.memberJoin(vo);
		
		return "login.jsp";
	}
	
	@RequestMapping(method=RequestMethod.POST, value="/login.do")
	public String login(UserVO vo, HttpSession session, Model model){
		
		UserVO user = dao.login(vo);
		user.setFriendList((ArrayList)dao.getFriendList(user));
		
		
		if(user != null){
			session.setAttribute("user", user);
			session.setAttribute("host", user);
			System.out.println((UserVO)session.getAttribute("host"));
			
			HashMap<String, Object> map = new HashMap<>();
			map.put("b_receiver", user.getUserid());
			map.put("pageNo", 1);

			int countBoard = boardDao.getCountBoard(user.getUserid());
			
			if(countBoard > 0){
				BoardVO board = boardDao.getBoardWithPageNo(map);
				model.addAttribute("board", boardDao.getBoardWithPageNo(map));
				model.addAttribute("boardCount", boardDao.getCountBoard(user.getUserid()));

			}//else{
//				board = new BoardVO();
//				board.setB_title("환영합니다. "+user.getName()+"님!");
//				board.setB_content("가입해 주셔서 감사합니다.");
//				model.addAttribute("board", board);
			//		}
			
			return "index.jsp";
			
		} else{
			return "login.jsp";
		}
	}
	
	@RequestMapping("/updateUser.do")
	public String updateUser(UserVO vo, HttpSession session){
		dao.updateUser(vo);
		UserVO user = dao.login(vo);
		session.setAttribute("user", user);
		return "updateUser.jsp";
	}
	
	@RequestMapping("/getUserList.do")
	public String getUserList(UserVO vo, Model md){
		
		md.addAttribute("userList", dao.getUserList(vo));
		return "userList.jsp";
	}
	
	@RequestMapping("/logout.do")
	public String logout(HttpSession session){
		session.invalidate();
		
		return "login.jsp";
	}
	
	@RequestMapping("/withdraw.do")
	public String withdraw(HttpSession session){
		UserVO vo = (UserVO)session.getAttribute("user");
		dao.withdraw(vo);
		
		return "login.jsp";
	}
	
	@RequestMapping("/follow.do")
	@ResponseBody
	public ArrayList<String> follow(String friendId, HttpSession session){
		
		UserVO vo = (UserVO)session.getAttribute("user");
		FriendVO voo = new FriendVO(vo.getUserid(), friendId);
		dao.follow(voo);
		
		ArrayList<String> friendList = (ArrayList) dao.getFriendList(vo);
		vo.setFriendList(friendList);
		session.setAttribute("user", vo);
		
		return friendList;
	}
	
	@RequestMapping("/checkFriend.do")
	@ResponseBody
	public HashMap<String, Boolean> checkFriend(String friendId, HttpSession session){
		UserVO vo = (UserVO)session.getAttribute("user");
		FriendVO voo = new FriendVO(vo.getUserid(), friendId);
		String friend = dao.checkFriend(voo);
		
		HashMap<String, Boolean> hm = new HashMap<>();
				
		if(friend!=null){
			hm.put("flag", false);
		}else{
			hm.put("flag", true);
		}
		
		return hm;
	}
	
	@RequestMapping("/unfollow.do")
	@ResponseBody
	public ArrayList<String> unfollow(String friendId, HttpSession session){
		UserVO vo = (UserVO)session.getAttribute("user");
		FriendVO voo = new FriendVO(vo.getUserid(), friendId);
		dao.unfollow(voo);
		
		ArrayList<String> friendList = (ArrayList) dao.getFriendList(vo);
		vo.setFriendList(friendList);
		session.setAttribute("user", vo);
		
		return friendList;
	}
	
	@RequestMapping("/friendBulogu.do")
	public String friendBulogu(String hostId, HttpSession session, Model model){
		
		UserVO host = (UserVO)dao.getUser(hostId);
		host.setFriendList((ArrayList)dao.getFriendList(host));
		session.setAttribute("host", host);
		
		HashMap<String, Object> map = new HashMap<>();
		map.put("b_receiver", host.getUserid());
		map.put("pageNo", 1);

		int countBoard = boardDao.getCountBoard(host.getUserid());
		
		if(countBoard > 0){
			BoardVO board = boardDao.getBoardWithPageNo(map);
			model.addAttribute("board", boardDao.getBoardWithPageNo(map));
			model.addAttribute("boardCount", boardDao.getCountBoard(host.getUserid()));

		}
		
		return "index.jsp";
	}
}
