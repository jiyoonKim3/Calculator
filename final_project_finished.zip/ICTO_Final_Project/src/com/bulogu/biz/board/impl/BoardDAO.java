package com.bulogu.biz.board.impl;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bulogu.biz.board.vo.BoardVO;
import com.bulogu.biz.comment.vo.CommentVO;

@Repository("boardDAO")
public class BoardDAO {

	@Autowired
	private SqlSession myBatis;
	
	public void addBoard(BoardVO vo){
		
		myBatis.insert("addBoard", vo);
		
	}
	
	public void updateBoard(BoardVO vo){
		myBatis.update("updateBoard", vo);
	}
	
	public void deleteBoard(int b_no){
		myBatis.delete("deleteCommentWithBoardNo", b_no);
		myBatis.delete("deleteBoard", b_no);
	}
	
	public BoardVO getBoard(int b_no){
		return myBatis.selectOne("getBoard", b_no);
	}

	public BoardVO getBoardWithPageNo(HashMap<String, Object> map) {
		
		BoardVO board = (BoardVO)myBatis.selectOne("getBoardWithPageNo", map);
		board.setCommentList((ArrayList)myBatis.selectList("getCommentList", board.getB_no()));
		for (CommentVO c : board.getCommentList()) {
			System.out.println(c);
		}
		return board;
	}
	
	public int getCountBoard(String userid) {
		
		return myBatis.selectOne("getBoardCount", userid);
	}
}
