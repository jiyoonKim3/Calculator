package com.bulogu.biz.board.vo;

import java.util.ArrayList;

import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import com.bulogu.biz.comment.vo.CommentVO;

@Component("boardVO")
public class BoardVO {
	
	private int b_no;
	private String b_writer;
	private String b_receiver;
	private String b_title;
	private String b_content;
	// 파일 업로드 용
	private String b_picture;
	private String b_date;
	private ArrayList<CommentVO> commentList;
	private MultipartFile uploadFile;
	
	public BoardVO() {
	}

	
	public int getB_no() {
		return b_no;
	}
	public void setB_no(int b_no) {
		this.b_no = b_no;
	}
	public String getB_writer() {
		return b_writer;
	}
	public void setB_writer(String b_writer) {
		this.b_writer = b_writer;
	}
	public String getB_receiver() {
		return b_receiver;
	}
	public void setB_receiver(String b_receiver) {
		this.b_receiver = b_receiver;
	}
	public String getB_title() {
		return b_title;
	}
	public void setB_title(String b_title) {
		this.b_title = b_title;
	}
	public String getB_content() {
		return b_content;
	}
	public void setB_content(String b_content) {
		this.b_content = b_content;
	}
	public String getB_picture() {
		return b_picture;
	}
	public void setB_picture(String b_picture) {
		this.b_picture = b_picture;
	}
	public String getB_date() {
		return b_date;
	}
	public void setB_date(String b_date) {
		this.b_date = b_date;
	}
	public ArrayList<CommentVO> getCommentList() {
		return commentList;
	}
	public void setCommentList(ArrayList<CommentVO> commentList) {
		this.commentList = commentList;
	}
	public MultipartFile getUploadFile() {
		return uploadFile;
	}
	public void setUploadFile(MultipartFile uploadFile) {
		this.uploadFile = uploadFile;
	}
	@Override
	public String toString() {
		return "BoardVO [b_no=" + b_no + ", b_writer=" + b_writer
				+ ", b_receiver=" + b_receiver + ", b_title=" + b_title
				+ ", b_content=" + b_content + ", b_picture=" + b_picture
				+ ", b_date=" + b_date + ", commentList=" + commentList
				+ ", uploadFile=" + uploadFile + "]";
	}	
}
