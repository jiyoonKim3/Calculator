package com.bulogu.biz.comment.vo;

import org.springframework.stereotype.Component;

@Component
public class CommentVO {
	private int c_no;
	private int b_no;
	private String c_writer;
	private String c_content;
	private String c_date;
	
	public CommentVO() {
	}

	public CommentVO(int c_no, int b_no, String c_writer, String c_content,
			String c_date) {
		super();
		this.c_no = c_no;
		this.b_no = b_no;
		this.c_writer = c_writer;
		this.c_content = c_content;
		this.c_date = c_date;
	}

	public int getC_no() {
		return c_no;
	}

	public void setC_no(int c_no) {
		this.c_no = c_no;
	}

	public int getB_no() {
		return b_no;
	}

	public void setB_no(int b_no) {
		this.b_no = b_no;
	}

	public String getC_writer() {
		return c_writer;
	}

	public void setC_writer(String c_writer) {
		this.c_writer = c_writer;
	}

	public String getC_content() {
		return c_content;
	}

	public void setC_content(String c_content) {
		this.c_content = c_content;
	}

	public String getC_date() {
		return c_date;
	}

	public void setC_date(String c_date) {
		this.c_date = c_date;
	}

	@Override
	public String toString() {
		return "CommentVO [c_no=" + c_no + ", b_no=" + b_no + ", c_writer="
				+ c_writer + ", c_content=" + c_content + ", c_date=" + c_date
				+ "]";
	}
}
