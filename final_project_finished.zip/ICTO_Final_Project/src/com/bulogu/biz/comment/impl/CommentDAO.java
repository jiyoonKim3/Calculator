package com.bulogu.biz.comment.impl;

import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bulogu.biz.comment.vo.CommentVO;

@Repository("commentDAO")
public class CommentDAO {

	@Autowired
	private SqlSession myBatis = null;
	
	public void addComment(CommentVO vo){
		myBatis.insert("addComment", vo);
	}
	
	public ArrayList<CommentVO> getCommentList(int b_no){
		
		ArrayList<CommentVO> list = (ArrayList) myBatis.selectList("getCommentList", b_no);
		for (CommentVO commentVO : list) {
			System.out.println(commentVO);
		}
		
		return (ArrayList) myBatis.selectList("getCommentList", b_no);
	}

	public void deleteComment(int c_no) {
		myBatis.delete("deleteComment", c_no);
		
	}

	public void updateComment(CommentVO vo) {
		System.out.println("수정된 코멘트"+vo);
		myBatis.update("updateComment", vo);
		
	}
	
}
