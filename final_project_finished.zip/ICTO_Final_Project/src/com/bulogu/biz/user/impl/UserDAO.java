package com.bulogu.biz.user.impl;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bulogu.biz.user.vo.FriendVO;
import com.bulogu.biz.user.vo.UserVO;

@Repository("userDAO")
public class UserDAO {
	
	@Autowired
	private SqlSession myBatis = null;
	
	public UserVO login(UserVO vo){
		UserVO user = myBatis.selectOne("login", vo);
		return user;
	}
	
	public void memberJoin(UserVO vo){
		myBatis.insert("joinUser", vo);
	}
	
	public void updateUser(UserVO vo){
		myBatis.update("updateUser", vo);
	}
	
	public ArrayList<UserVO> getUserList(UserVO vo){
		ArrayList<UserVO> user = (ArrayList) myBatis.selectList("getUserList", vo);
		return user;
	}
	
	public void follow(FriendVO vo){
		myBatis.insert("follow", vo);
	}
	
	public void unfollow(FriendVO vo){
		myBatis.delete("unfollow", vo);
	}
	
	public String checkFriend(FriendVO vo){
		return myBatis.selectOne("checkFriend", vo);
	}
	
	public List<String> getFriendList(UserVO vo){
		return myBatis.selectList("getFriendList", vo);
	}
		
	public void withdraw(UserVO vo){
		myBatis.delete("deleteCommentWithUserId", vo);
		myBatis.delete("deleteBoardCommentWithUserId", vo);
		myBatis.delete("deleteBoardWithUserId", vo);
		myBatis.delete("deleteFriendWithUserId", vo);
		myBatis.delete("deleteUser", vo);
	}
	
	public void logout(){
		
	}

	public UserVO getUser(String hostId) {

		return myBatis.selectOne("getUser", hostId);
	}
}
