package com.bulogu.biz.user.vo;

import java.util.ArrayList;

import org.springframework.stereotype.Component;

@Component("userVO")
public class UserVO {
	private String userid;
	private String name;
	private String password;
	private String email;
	private ArrayList<String> friendList;
	public UserVO() {
		// TODO Auto-generated constructor stub
	}
	
	public UserVO(String userid, String name, String password, String email,
			ArrayList<String> friendList) {
		super();
		this.userid = userid;
		this.name = name;
		this.password = password;
		this.email = email;
		this.friendList = friendList;
	}

	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public ArrayList<String> getFriendList() {
		return friendList;
	}
	public void setFriendList(ArrayList<String> friendList) {
		this.friendList = friendList;
	}
	@Override
	public String toString() {
		return "UserVO [userid=" + userid + ", name=" + name + ", password="
				+ password + ", email=" + email + ", friendList=" + friendList
				+ "]";
	}
}
