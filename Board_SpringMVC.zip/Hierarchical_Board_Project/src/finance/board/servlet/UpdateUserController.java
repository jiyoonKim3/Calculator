package finance.board.servlet;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import finance.board.dao.UserDAO;
import finance.board.vo.UserVO;


public class UpdateUserController implements Controller {

	@Override
	public ModelAndView handleRequest(HttpServletRequest request,
		HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		UserDAO userDao = UserDAO.getinstance();

		String userid = request.getParameter("userid").trim();
		String password = request.getParameter("password").trim();
		String name = request.getParameter("name").trim();
		String email = request.getParameter("email").trim();
		UserVO user = new UserVO(userid, password, name, email);
		try {
			userDao.updateUser(user);
			HttpSession s = request.getSession();
			s.setAttribute("User", user);
			mav.addObject("content", "update.jsp");
		} catch (SQLException e) {
			e.printStackTrace();
			mav.addObject("content", "/Error.jsp");
		}
		mav.setViewName("menu.jsp");
		return mav;
	}

}
