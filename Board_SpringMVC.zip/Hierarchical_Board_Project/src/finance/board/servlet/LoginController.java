package finance.board.servlet;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import finance.board.dao.UserDAO;
import finance.board.vo.UserVO;

public class LoginController implements Controller {

	@Override
	public ModelAndView handleRequest(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		UserDAO userDao = UserDAO.getinstance();
		ModelAndView mav = new ModelAndView();
		
		String userid = request.getParameter("userid");
		String password = request.getParameter("password");
		try {
			boolean flag= userDao.login(userid, password);
			if (flag) {
				HttpSession s = request.getSession();
				UserVO user = new UserVO();
				user = userDao.selectUser(userid);
				s.setAttribute("User", user);
				
				mav.setViewName("getBoardList.do");
			}else{
				request.setAttribute("msg", "아이디 또는 비밀번호가 일치하지 않거나 해당 회원이 존재하지 않습니다.");
				request.setAttribute("content", "Error.jsp");
				mav.setViewName("menu.jsp");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return mav;
		
	}

}
