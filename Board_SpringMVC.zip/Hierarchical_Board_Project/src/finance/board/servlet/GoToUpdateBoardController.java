package finance.board.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import finance.board.dao.BoardDAO;
import finance.board.vo.BoardVO;

/**
 * Servlet implementation class DeleteBoard
 */
/*@WebServlet("/goToUpdateBoard.do")*/
public class GoToUpdateBoardController implements Controller {
	@Override
	public ModelAndView handleRequest(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		int boardNo = Integer.parseInt(request.getParameter("boardNo"));
		
		BoardDAO dao = new BoardDAO();
		BoardVO board = dao.getBoard(boardNo);
		mav.addObject("board", board);
		mav.addObject("content", "boardUpdate.jsp");
		mav.setViewName("menu.jsp");
		return mav;
	}

}
