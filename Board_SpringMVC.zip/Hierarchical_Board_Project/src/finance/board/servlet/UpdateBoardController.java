package finance.board.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import finance.board.dao.BoardDAO;
import finance.board.vo.BoardVO;

/**
 * Servlet implementation class DeleteBoard
 */
/*@WebServlet("/updateBoard.do")*/
public class UpdateBoardController implements Controller{
	@Override
	public ModelAndView handleRequest(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		int boardNo = Integer.parseInt(request.getParameter("boardNo"));
		String boardUserId = request.getParameter("boardUserId");
		String boardTitle = request.getParameter("boardTitle");
		String boardContent = request.getParameter("boardContent");
		
		BoardVO board = new BoardVO(boardNo, boardTitle, boardContent, boardUserId, null);		
		BoardDAO dao = new BoardDAO();
		int result = dao.updateBoard(board);
		mav.setViewName("getBoardList.do");
		return mav;
	}

}
