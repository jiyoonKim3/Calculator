package finance.board.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import finance.board.vo.UserVO;

/**
 * Servlet implementation class DeleteBoard
 */
/*@WebServlet("/goToAddBoard.do")*/
public class GoToAddBoardController implements Controller{
	@Override
	public ModelAndView handleRequest(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		HttpSession session = request.getSession(false);
		UserVO user = new UserVO("jiyoon", "jiyoon", "jiyoon", "jiyoon@samsung.com");
		mav.addObject("User", user);
		mav.addObject("content", "boardWrite.jsp");
		mav.setViewName("menu.jsp");
		return mav;
	}

}
