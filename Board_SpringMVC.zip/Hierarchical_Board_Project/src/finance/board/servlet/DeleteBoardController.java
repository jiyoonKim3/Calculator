package finance.board.servlet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import finance.board.dao.BoardDAO;

/**
 * Servlet implementation class DeleteBoard
 */
/*@WebServlet("/deleteBoard.do")*/
public class DeleteBoardController implements Controller {
	@Override
	public ModelAndView handleRequest(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		int boardNo = Integer.parseInt(request.getParameter("boardNo"));
		BoardDAO dao = new BoardDAO();
		int result = dao.deleteBoard(boardNo);
		mav.setViewName("getBoardList.do");
		return mav;
	}
}
