package finance.board.servlet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import finance.board.dao.UserDAO;
import finance.board.vo.UserVO;

public class RegisterUserController implements Controller {

	@Override
	public ModelAndView handleRequest(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		ModelAndView mav = new ModelAndView();
				
		UserDAO userDao = UserDAO.getinstance();
		try {
			String userid = request.getParameter("userid").trim();
			String password = request.getParameter("password").trim();
			String name = request.getParameter("name").trim();
			String email = request.getParameter("email").trim();
			UserVO user = new UserVO(userid, password, name, email);
			userDao.insertUser(user);
			request.setAttribute("content", "login.jsp");
		} catch (Exception e) {
			e.printStackTrace();
//			request.setAttribute("content", "/Error.jsp");
		}
		mav.setViewName("menu.jsp");
		return mav;
	}

}
