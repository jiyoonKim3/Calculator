package finance.board.servlet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

public class LogoutController implements Controller {

	@Override
	public ModelAndView handleRequest(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		ModelAndView mav = new ModelAndView();
				
		HttpSession s = request.getSession(false);
		if (s != null) {
			s.invalidate();
		}
		request.setAttribute("content", "login.jsp");
		mav.setViewName("menu.jsp");
		return mav;
		
	}

}
