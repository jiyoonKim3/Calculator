package finance.board.servlet;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import finance.board.dao.UserDAO;
import finance.board.vo.UserVO;


public class DeleteUserController implements Controller {

	@Override
	public ModelAndView handleRequest(HttpServletRequest request,
		HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		UserDAO userDao = UserDAO.getinstance();
		HttpSession s = request.getSession();
		UserVO user = (UserVO) s.getAttribute("User");
		try {
			userDao.deleteUser(user);
			mav.addObject("content","login.jsp");
		} catch (SQLException e) {
			e.printStackTrace();
			mav.addObject("content","/Error.jsp");
		}
		s.invalidate();
		
		mav.setViewName("menu.jsp");
		return mav;
	}

}
