package finance.board.servlet;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import finance.board.dao.UserDAO;
import finance.board.vo.UserVO;

public class GetUserListController implements Controller {

	@Override
	public ModelAndView handleRequest(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		UserDAO userDao = UserDAO.getinstance();
		ModelAndView mav = new ModelAndView();
		
		try {
			ArrayList<UserVO> list = userDao.selectUserList();
			
			for (UserVO userVO : list) {
				System.out.println(userVO);
			}
			
			request.setAttribute("userList", list);
			request.setAttribute("content", "userList.jsp");
		} catch (SQLException e) {
			e.printStackTrace();
//			request.setAttribute("content", "/Error.jsp");
		}
		mav.setViewName("menu.jsp");
		return mav;
		
	}

}
