package finance.board.servlet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import finance.board.dao.BoardDAO;
import finance.board.vo.BoardVO;
import finance.board.vo.UserVO;

/**
 * Servlet implementation class DeleteBoard
 */
/*@WebServlet("/insertBoard.do")*/
public class AddBoardController implements Controller{

	@Override
	public ModelAndView handleRequest(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		HttpSession session = request.getSession(false);
		UserVO user = (UserVO)session.getAttribute("User");
		
		String boardUserId = user.getUserId();
		String boardTitle = request.getParameter("boardTitle");
		String boardContent = request.getParameter("boardContent");
		
		BoardVO board = new BoardVO(0, boardTitle, boardContent, boardUserId, null);		
		
		BoardDAO dao = new BoardDAO();
		int result = dao.insertBoard(board);
		
		mav.setViewName("getBoardList.do");
		return mav;
	}

}
