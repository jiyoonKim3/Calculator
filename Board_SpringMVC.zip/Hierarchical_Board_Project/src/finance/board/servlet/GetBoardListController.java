package finance.board.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import finance.board.dao.BoardDAO;
import finance.board.vo.BoardVO;

/**
 * Servlet implementation class GetBoardList
 */
/*@WebServlet("/getBoardList.do")*/
public class GetBoardListController implements Controller{
	@Override
	public ModelAndView handleRequest(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		BoardDAO dao = new BoardDAO();
		ArrayList<BoardVO> boardList = dao.getBoardList();
		HttpSession s = request.getSession();
		mav.addObject("boardList", boardList);
		mav.addObject("content", "boardList.jsp");
		mav.setViewName("menu.jsp");
		return mav;
	}

}
