package finance.board.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import finance.board.util.JDBCUtils;
import finance.board.vo.UserVO;

@Repository("userDAO")
public class UserDAO {
	
	private UserDAO(){}
	
	private static UserDAO instance = new UserDAO();
	
	public static UserDAO getinstance(){
		return instance;
	}
	
	public void insertUser(UserVO user) throws SQLException{
		Connection con = null;
		PreparedStatement ps = null;
		try {
			con = JDBCUtils.getConnection();
			String sql = "Insert into Userinfo values(?, ?, ?, ?)";
			ps = con.prepareStatement(sql);
			ps.setString(1, user.getUserId());
			ps.setString(2, user.getPassword());
			ps.setString(3, user.getName());
			ps.setString(4, user.getEmail());
			ps.executeUpdate();
		} finally {
			JDBCUtils.close(ps, con);
		}
	}
	
	public UserVO selectUser(String userid) throws SQLException{
		UserVO user = null;
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = JDBCUtils.getConnection();
			String sql = "Select * from Userinfo Where userid = ?";
			ps = con.prepareStatement(sql);
			ps.setString(1, userid);
			rs = ps.executeQuery();
			if(rs.next()){
				user = new UserVO(rs.getString(1), rs.getString(2), rs.getString(3),rs.getString(4));
			}
		} finally {
			JDBCUtils.close(rs, ps, con);
		}
		return user;
	}
	
	public ArrayList<UserVO> selectUserList() throws SQLException{
		ArrayList<UserVO> list = new ArrayList<UserVO>();
		
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = JDBCUtils.getConnection();
			String sql = "Select * from Userinfo order by userId";
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()){
				UserVO user = new UserVO(rs.getString(1), rs.getString(2), rs.getString(3),rs.getString(4));
				list.add(user);
			}
		} finally {
			JDBCUtils.close(rs, ps, con);
		}
		return list;
	}
	
	public void updateUser(UserVO user) throws SQLException{
		Connection con = null;
		PreparedStatement ps = null;
		try {
			con = JDBCUtils.getConnection();
			String sql = "Update Userinfo Set password = ?, name = ?, email = ? Where userid = ?";
			ps = con.prepareStatement(sql);
			ps.setString(1, user.getPassword());
			ps.setString(2, user.getName());
			ps.setString(3, user.getEmail());
			ps.setString(4, user.getUserId());
			ps.executeUpdate();
		} finally {
			JDBCUtils.close(ps, con);
		}
	}
	
	public void deleteUser(UserVO user) throws SQLException{
		Connection con = null;
		PreparedStatement ps = null;
		try {
			con = JDBCUtils.getConnection();
			String sql = "Delete Userinfo Where userid = ?";
			ps = con.prepareStatement(sql);
			ps.setString(1, user.getUserId());
			ps.executeUpdate();
		} finally {
			JDBCUtils.close(ps, con);
		}
	}

	public boolean login(String userid, String password) throws SQLException {
		boolean flag = false;
		UserVO user = selectUser(userid);
		if(user!=null && password.equals(user.getPassword())){
			flag = true;
		}
		return flag;
	}
	
}
